export default {
  render({ model, el, signal }) {
    const out = document.createElement("div");
    out.className = "gauge";
    const show = () => { out.textContent = `${model.get("label")}: ${model.get("value")}`; };
    model.on("change:value", show);
    signal.addEventListener("abort", () => model.off("change:value", show));
    show();
    el.append(out);
  },
};
