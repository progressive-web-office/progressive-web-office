"""A tiny anywidget package, for the tests of Progressive Web Office (CODE-016)."""
import pathlib
import anywidget
import traitlets


class Gauge(anywidget.AnyWidget):
    _esm = pathlib.Path(__file__).parent / "gauge.js"
    _css = ".gauge { font: 600 18px sans-serif; color: rgb(0, 102, 51); }"
    value = traitlets.Float(0).tag(sync=True)
    label = traitlets.Unicode("").tag(sync=True)
